DECISIONTIME = 17 # +7 seconds for lag
DEBUG = True
FONT = 'aerxtablets'
#FONT = None
